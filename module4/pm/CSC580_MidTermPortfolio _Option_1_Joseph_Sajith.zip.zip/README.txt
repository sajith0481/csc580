Quick Start
-----------
1) Install dependencies:
   pip install face_recognition opencv-python pillow

2) Run:
   python face_match.py --individual "image1.jpg" --group "image2.jpg" --out annotated.png --tolerance 0.6
